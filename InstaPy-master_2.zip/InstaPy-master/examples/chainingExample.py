from instapy import InstaPy

InstaPy(username='test', password='test') \
    .login() \
    .set_do_comment(True, percentage=10) \
    .set_comments(['Cool!', 'Awesome!', 'Nice!']) \
    .set_dont_include(['friend1', 'friend2', 'friend3']) \
    .set_dont_like(['food', 'girl', 'hot']) \
    .like_by_tags(['dog', '#cat'], amount=2) \
    .end()
